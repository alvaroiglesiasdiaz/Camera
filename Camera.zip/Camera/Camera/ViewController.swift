//
//  ViewController.swift
//  Camera
//
//  Created by user177270 on 2/8/21.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {

    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let selectorImagen = UIImagePickerController()
        selectorImagen.delegate = self
        selectorImagen.sourceType = .photoLibrary
        present(selectorImagen, animated: true, completion: nil)
        
        let fileManager = FileManager.default

        let imagePath =
            (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as
                NSString).appendingPathComponent("foto.jpg")

        fileManager.createFile(atPath: imagePath as
        String, contents:
            imageView.image?.jpegData(compressionQuality: 1.0))
        
        
        if fileManager.fileExists(atPath: imagePath) {
        imageView.image = UIImage(contentsOfFile:
        imagePath)
        } else {
            print("La imagen no existe")
        }
    }

    func imagePickerController(_ picker: UIImagePickerController,
    didFinishPickingMediaWithInfo info: [String : Any]) {
        let imagen = info[UIImagePickerController.InfoKey.originalImage.rawValue]
    as! UIImage
    imageView.image = imagen
    dismiss(animated: true, completion: nil)
    }
}


